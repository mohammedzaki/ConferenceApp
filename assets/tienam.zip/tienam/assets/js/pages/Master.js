$(document).ready(function () {
    $('#pop1').bind('touchend', function(event) {            
        window.location = "index-2.html";
    });
    $('#pop2').bind('touchend', function(event) {            
        window.location = "2.html";
    });
    $('#pop3').bind('touchend', function(event) {            
        window.location = "9.html";
    });    
});